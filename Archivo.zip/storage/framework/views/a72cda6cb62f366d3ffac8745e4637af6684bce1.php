<?php
/**@var  \App\Models\Compra[]  $compras*/
/**@var  int $id*/
$totalCompras = 0;
foreach($compras as $compra){
    if($compra->usuario_id == $id) {
        $totalCompras += 1;
    }
}
?>



<?php $__env->startSection('title', 'Mis compras'); ?>

<?php $__env->startSection('main'); ?>

<section class="container seccionesLargoMinimo bg-white p-5 rounded">
    <?php if($id == Auth::user()->usuario_id): ?>
        <h1 class="fs-1 mb-3">Mis compras (<?php echo e(Auth::user()->nombre); ?> <?php echo e(Auth::user()->apellido); ?>):</h1>
        <article>
            <?php if($totalCompras == 0): ?>
                <h2 class="text-center fs-2 my-5">Aún no ha realizado ninguna compra.</h2>
                <div class="d-flex justify-content-center">
                    <a href="<?php echo e(route('contratar')); ?>" class="my-3 fs-5 text-center text-white botonVioleta w-50">Contrata nuestros servicios</a>
                </div>
            <?php else: ?>
                <table class="table table-hover table-bordered mb-2">
                    <thead>
                        <tr>
                            <th>Id de la compra</th>
                            <th>Servicio contratado</th>
                            <th>Fecha</th>
                            <th>Total</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>    
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($compra->usuario_id == $id): ?>
                                <tr> 
                                    <td><?php echo e($compra->compra_id); ?></td>
                                    <td>
                                        <?php if($compra->servicio_id == 1): ?>
                                            Asesoría básica
                                        <?php else: ?>
                                            Asesoría en vivo
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($compra->fecha); ?></td>
                                    <td>$<?php echo e($compra->total); ?></td> 
                                    <td>
                                        <?php if($compra->estado == 1): ?>
                                            <p class="pendiente text-center mx-auto my-auto p-2 text-white">Pendiente</p>
                                        <?php else: ?>
                                            <p class="finalizada text-center mx-auto my-auto p-2 text-white">Finalizada</p>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($compra->estado == 1): ?>
                                            <a href="<?php echo e(route('comprasCancelar', ['compra_id' => $compra->compra_id])); ?>" class="btn btn-danger p-2 w-100 mx-auto my-auto">Cancelar</a>
                                        <?php else: ?>
                                            <p class="text-center mx-auto my-auto fs-4">-</p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </article> 
    <?php else: ?>
    <div class="d-flex flex-column justify-content-center align-items-center">
        <h1 class="fs-1 mb-3 text-center my-auto">No puedes ver las compras de otros usuarios</h1>
        <a href="<?php echo e(route('compras', ['id' => Auth::user()->usuario_id])); ?>" class="my-3 fs-5 text-center text-white botonVioleta w-50 my-3">Ver mis compras</a>
    </div>
    <?php endif; ?>
 </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/compras.blade.php ENDPATH**/ ?>