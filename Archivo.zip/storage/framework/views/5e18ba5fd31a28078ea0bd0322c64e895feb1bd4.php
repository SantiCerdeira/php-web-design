<?php
/**@var  \App\Models\Articulo  $articulo*/
?>



<?php $__env->startSection('title', 'Debes confirmar que eres mayor de edad'); ?>

<?php $__env->startSection('main'); ?>
<article class="container seccionesLargoMinimo bg-white p-5 rounded">
    <h1 class="fs-1 mb-3 text-center">Confirmación de edad</h1>
    <p class="text-center">Debido a que el artículo que deseas leer puede contener información acerca de dinero y finanzas, te pedimos que por favor confirmes que eres mayor de 18 años para poder leerlo.</p>
    
    <form action="<?php echo e(route('confirmar.edad', ['id' => $articulo->articulo_id])); ?>" class="d-flex justify-content-center" method="post">
        <?php echo csrf_field(); ?>
        <a href="<?php echo e(route('articulos')); ?>" class="btn btn-danger mx-3">No soy mayor de edad</a>
        <button type="submit" class="btn btn-dark mx-3">Soy mayor de 18 años</button>
    </form>
</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/confirmar-edad.blade.php ENDPATH**/ ?>