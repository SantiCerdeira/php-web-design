<?php
/**@var  \App\Models\Articulo  $articulo*/
?>



<?php $__env->startSection('title', 'Eliminar ' . $articulo->titulo); ?>

<?php $__env->startSection('main'); ?>
<section class="container my-3">
    <article>
        <h1>Eliminar "<?php echo e($articulo->titulo); ?>"</h1>
    
        <?php echo $__env->make('_articuloData', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <h2>¿Desea confirmar la eliminación de esta articulo?</h2>
        <form action="<?php echo e(route('admin.articulos.eliminar', ['id' => $articulo->articulo_id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger p-2 my-2">Eliminar</button>
        </form>
    </article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/admin/adminEliminarConfirmar.blade.php ENDPATH**/ ?>