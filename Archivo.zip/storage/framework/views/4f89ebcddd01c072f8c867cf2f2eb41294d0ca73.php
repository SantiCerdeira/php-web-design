<?php
/**@var  \App\Models\Camiseta  $camiseta*/
?>

<div class="row mb-3">
        <div class="col-6">
            Aca va imagen
        </div>
        <div class="col-6">
            <dl>
                <dt>Precio</dt>
                <dd>$<?php echo e($camiseta->precio); ?></dd>
                <dt>País</dt>
                <dd>$<?php echo e($camiseta->pais); ?></dd>
            </dl>
        </div>
    </div>

    <h2>Descripción</h2>
    <p><?php echo e($camiseta->descripcion); ?></p><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/_camisetaData.blade.php ENDPATH**/ ?>