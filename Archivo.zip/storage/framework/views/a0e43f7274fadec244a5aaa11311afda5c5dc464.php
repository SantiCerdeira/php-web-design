<?php
/** @var \Illuminate\Database\Elocuent\Collection | \App\Models\Articulo[] $articulos */
?>


<?php $__env->startSection('title', 'Blog de WebExpert'); ?>

<?php $__env->startSection('main'); ?>
<section class="seccionesLargoMinimo">
    <h1 class="fs-1 text-center mt-3 p-3 text-white">Blog de WebExpert</h1>
    <?php if(count($articulos) == 0): ?>
        <div class="d-flex flex-column justify-content-center">
            <h2 class="fs-2 text-center mt-5 p-3 text-white">Por el momento no hay artículos en nuestro blog... :(</h2>
            <a href="<?= route('inicio');?>" class="btn btn-dark p-3 fs-4 w-50 mx-auto my-3 boton">Volver al inicio</a>
        </div>
    <?php else: ?>
        <h2 class="visually-hidden">Lista de artículos</h2>
            <div class="d-flex justify-content-lg-around row my-4 mx-auto">
                <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="col-10 col-md-5 col-xl-3 mx-auto mx-xl-3 my-4 card p-1 d-flex text-center fondo items d-flex flex-column justify-content-between articuloBlog">
                        <figure>
                            <img src="<?php echo e(url('img/' . $articulo->portada)); ?>" alt="<?php echo e($articulo->portada_descripcion); ?>" class="mx-auto portadas">
                        </figure>
                        <h2 class="my-3"><a href="<?php echo e(route('articulos.detalle', ['id' => $articulo->articulo_id])); ?>"  class="text-decoration-none text-dark"><?php echo e($articulo->titulo); ?></a></h2>
                        <p class="fst-italic">Escrito por: <?php echo e($articulo->usuario->nombre); ?> <?php echo e($articulo->usuario->apellido); ?></p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/articulos.blade.php ENDPATH**/ ?>