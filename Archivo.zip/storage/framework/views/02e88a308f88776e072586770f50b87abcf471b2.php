<?php
/**@var  \App\Models\Compra[]  $compras*/
/**@var  \App\Models\Usuario  $usuario*/
/**@var  int $id*/
$totalCompras = 0;
foreach($compras as $compra){
    if($compra->usuario_id == $id) {
        $totalCompras += 1;
    }
}
?>



<?php $__env->startSection('title', 'Compras de ' . $usuario->nombre . ' ' . $usuario->apellido); ?>

<?php $__env->startSection('main'); ?>
<section class="container my-3">
    <h1>Compras de <?php echo e($usuario->nombre); ?> <?php echo e($usuario->apellido); ?></h1>
    <a href="<?php echo e(route('admin.usuarios')); ?>" class="btn btn-dark fs-4 fw-bold my-3 text-decoration-none text-white">Volver al listado de usuarios</a>

    <article>
        <?php if($totalCompras == 0): ?>
            <h2 class="text-center fs-2 my-5">Este usuario no ha realizado ninguna compra.</h2>
        <?php else: ?>
            <table class="table table-hover table-bordered mb-2">
                <thead>
                    <tr>
                        <th>Id de la compra</th>
                        <th>Servicio contratado</th>
                        <th>Fecha</th>
                        <th>Total</th>
                        <th>Estado</th>
                    </tr>    
                </thead>
                <tbody>
                    <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($compra->compra_id); ?></td>
                            <td>
                                <?php if($compra->servicio_id == 1): ?>
                                    Asesoría básica
                                <?php else: ?>
                                    Asesoría en vivo
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($compra->fecha); ?></td>
                            <td>$<?php echo e($compra->total); ?></td> 
                            <td>
                                <?php if($compra->estado == 1): ?>
                                    <p class="pendiente text-center mx-auto my-auto p-2 text-white">Pendiente</p>
                                <?php else: ?>
                                    <p class="finalizada text-center mx-auto my-auto p-2 text-white">Finalizada</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/admin/adminComprasUsuario.blade.php ENDPATH**/ ?>