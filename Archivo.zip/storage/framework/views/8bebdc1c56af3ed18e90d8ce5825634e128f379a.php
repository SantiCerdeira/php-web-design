<?php
/** @var \MercadoPago\Preference  $preference*/
/** @var string  $publicKey*/
/** @var int  $servicio_id*/
session_start();
$_SESSION['servicio_id'] = $servicio_id;
?>



<?php $__env->startSection('title', 'Confirmar compra'); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://sdk.mercadopago.com/js/v2"></script>
    <script>
        const mp = new MercadoPago('<?php echo e($publicKey); ?>', {
          locale: 'es-AR'
        });
      
        mp.checkout({
          preference: {
            id: '<?php echo e($preference->id); ?>'
          },
          render: {
            container: '#container-mp',
          }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<section class="container seccionesLargoMinimo bg-white p-5 rounded">
    <h1 class="fs-1 text-center mt-3">Confirmar compra</h1>
    <article>
      <table class="table table-hover table-bordered my-3">
        <thead>
            <tr>
                <th>Servicio contratado</th>
                <th>Fecha</th>
                <th>Total</th>
            </tr>    
        </thead>
        <tbody>
          <?php $__currentLoopData = $preference->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr> 
                <td><?php echo e($item->title); ?></td>
                <td><?php echo e(date("Y-m-d")); ?></td>
                <td>$<?php echo e($item->unit_price * $item->quantity); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </article>   

    <div class="d-flex justify-content-center fs-5" id="container-mp">

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/mercadopago.blade.php ENDPATH**/ ?>