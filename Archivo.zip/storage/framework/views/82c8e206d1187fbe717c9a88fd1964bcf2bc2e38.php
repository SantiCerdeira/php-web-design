<?php
/**@var  \App\Models\Articulo  $articulo*/
?>



<?php $__env->startSection('title', $articulo->titulo); ?>

<?php $__env->startSection('main'); ?>
<article class="articuloDetalle container my-3 bg-white bg-gradient mx-auto">
    <h1 class="text-center my-2"><?php echo e($articulo->titulo); ?></h1>
    <p class="w-75 mx-auto text-center my-2"><?php echo e($articulo->descripcion); ?></p>
    <figure>
        <img src="<?php echo e(url('img/' . $articulo->portada)); ?>" alt="<?php echo e($articulo->portada_descripcion); ?>" class="imagenPortada my-4">
    </figure>
    <div class="w-75 mx-auto my-3 renglones"><?php echo $articulo->cuerpo; ?></div>
    <p class="w-75 mx-auto my-3 text-end">Escrito por: <?php echo e($articulo->usuario->nombre); ?> <?php echo e($articulo->usuario->apellido); ?></p>
</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/articulosDetalle.blade.php ENDPATH**/ ?>