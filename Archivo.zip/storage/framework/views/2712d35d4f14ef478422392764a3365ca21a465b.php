<?php
/**@var  \App\Models\Articulo  $articulo*/
?>



<?php $__env->startSection('title', $articulo->titulo); ?>

<?php $__env->startSection('main'); ?>
<section class="container my-3">
    <article>
        <h1><?php echo e($articulo->titulo); ?></h1>

        <?php echo $__env->make('_articuloData', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/adminDetalle.blade.php ENDPATH**/ ?>