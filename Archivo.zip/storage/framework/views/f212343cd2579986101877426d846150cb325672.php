<?php $__env->startSection('title', 'Bienvenido'); ?>

<?php $__env->startSection('main'); ?>
<section>
    <h1 class="fs-1 text-center mt-3 p-3 text-white">Blog de WebExpert</h1>
    <h2 class="visually-hidden">Lista de artículos</h2>
        <div class="d-flex justify-content-lg-around row my-4 mx-auto">
            <article class="col-10 col-md-5 col-xl-3 mx-auto mx-xl-3 my-4 card p-3 d-flex text-center fondo items d-flex flex-column justify-content-around">
                <div class="flex-column align-items-center">
                    <h2 class=""><a href="" class="text-decoration-none text-dark"></a></h2>
                    <img src="" alt="" width="80%" height="80%" class="m-2">
                </div>
                <div class="d-flex justify-content-between m-1 p-2">             
                    <form action="acciones/agregar-carrito.php" method="post">
                        <div class="infoProducto">
                            <input type="hidden" name="link" id="link" value="<?= "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?>"/>
                            <input type="hidden" name="id" id="id" value=""/>
                            <input type="hidden" name="imagen" id="imagen" value=""/>
                            <input type="hidden" name="titulo" id="titulo" value=""/>
                            <input type="hidden" name="precio" id="precio" value=""/>
                            <input type="hidden" name="cantidad" id="cantidad" value="1"/>
                            <button class="btn btn-dark px-2 py-1 fs-5">Comprar</button>
                        </div>
                    </form>
                </div>
            </article>
        </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/catalogo.blade.php ENDPATH**/ ?>