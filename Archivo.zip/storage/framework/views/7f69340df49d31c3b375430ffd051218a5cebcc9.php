<?php $__env->startSection('title', 'Panel de administración'); ?>

<?php $__env->startSection('main'); ?>
<section class="p-5">
    <h1 class="fs-1 text-center">Tablero de administración</h1>
    <a href="<?=route('admin.articulos');?>" class="btn btn-dark rounded text-white p-3 w-100 my-4">Administrar los artículos</a>
    <a href="<?= route('admin.usuarios');?>" class="btn btn-dark rounded text-white p-3 w-100 my-4">Administrar usuarios</a>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/adminHome.blade.php ENDPATH**/ ?>