<?php
/**@var  \Illuminate\Support\ViewErrorBag  $errors*/
/**@var  \App\Models\Servicio[]  $servicios*/
/**@var  $servicio_id*/
?>



<?php $__env->startSection('title', 'Formulario Contratación'); ?>

<?php $__env->startSection('main'); ?>
<section>
    <div class="w-100">
        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($servicio->servicio_id == $servicio_id): ?>
            <h1 class="fs-1 text-center mt-3 text-white">Formulario de contratación de <?php echo e($servicio->nombre); ?></h1>
            <h2 class="fs-3 text-center mt-3 text-white">Valor: $<?php echo e($servicio->precio); ?></h2>
                <form action="<?php echo e(route('crearCompra')); ?>" method="post" class="d-flex flex-column p-2 my-3 w-75 mx-auto formulario">
                    <?php echo csrf_field(); ?>
                    <div class="d-flex flex-column mb-3">
                        <label for="nombre" class="mt-3 mb-2 fw-bold fs-3">Nombre:</label>
                        <input 
                            type="text" 
                            name="nombre" 
                            id="nombre"
                            class="form-control mb-2 <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            value="<?php echo e(old('nombre', Auth::user()->nombre)); ?>"
                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="error-nombre" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        > 
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-danger text-white mb-3 p-1" id="error-nombre"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="d-flex flex-column mb-3">
                        <label for="apellido" class="mt-3 mb-2 fw-bold fs-3">Apellido:</label>
                        <input 
                            type="text" 
                            name="apellido" 
                            id="apellido"
                            class="form-control mb-2 <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            value="<?php echo e(old('apellido', Auth::user()->apellido)); ?>"
                            <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="error-apellido" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        > 
                        <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-danger text-white mb-3 p-1" id="error-apellido"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="d-flex flex-column mb-3">
                        <label for="email" class="mt-3 mb-2 fw-bold fs-3">Correo electrónico:</label>
                        <input 
                            type="text" 
                            name="email" 
                            id="email" 
                            class="form-control mb-2 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            value="<?php echo e(old('email', Auth::user()->email)); ?>"
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="error-email" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        > 
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-danger text-white mb-3 p-1" id="error-email"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="d-flex flex-column mb-3">
                        <label for="numero" class="mt-3 mb-2 fw-bold fs-3">Número telefónico:</label>
                        <input 
                            type="text" 
                            name="numero" 
                            id="numero" 
                            class="form-control mb-2 <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            value="<?php echo e(old('numero')); ?>"
                            <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="error-numero" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        > 
                        <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-danger text-white mb-3 p-1" id="error-numero"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="aclaracionBlanco" id="aclaracion-numero">El número debe tener al menos 8 caracteres</p>
                    </div>

                    <div class="d-flex flex-column mb-3">
                        <label for="link" class="mt-3 mb-2 fw-bold fs-3">URL de su sitio web que desea que revisemos:</label>
                        <input 
                            type="text" 
                            name="link" 
                            id="link" 
                            class="form-control mb-2 <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            value="<?php echo e(old('link')); ?>"
                            <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="error-link" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        > 
                        <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-danger text-white mb-3 p-1" id="error-link"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="d-flex flex-column mb-3">
                        <label for="total" class="mt-3 mb-2 fw-bold fs-3">Servicio a contratar:</label>
                        <select type="text" name="total" id="total" class="form-control">
                            <option 
                            value="<?php echo e($servicio->precio); ?>"
                            <?php if($servicio->servicio_id == $servicio_id): echo 'selected'; endif; ?>
                            ><?php echo e($servicio->nombre); ?> - $<?php echo e($servicio->precio); ?></option>
                        </select>
                    </div>

                    <div class="d-flex flex-column mb-3">
                        <label for="mensaje" class="mt-3 mb-2 fw-bold fs-3">Escriba en detalle acerca de su empresa y qúe busca mejorar:</label>
                        <textarea 
                            name="mensaje" 
                            id="mensaje" 
                            cols="30" rows="10" 
                            class="form-control mb-2 <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="error-mensaje" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        > <?php echo e(old('mensaje')); ?></textarea>
                        <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-danger text-white mb-3 p-1" id="error-mensaje"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="aclaracionBlanco" id="aclaracion-mensaje">El mensaje debe tener al menos 50 caracteres</p>
                    </div>

                    <input 
                        id="usuario_id" 
                        name="usuario_id" 
                        type="hidden"
                        value="<?php echo e(Auth::user()->usuario_id); ?>">

                    <input 
                        id="servicio_id" 
                        name="servicio_id" 
                        type="hidden"
                        value=<?php echo e($servicio_id); ?>>

                    <input 
                        id="fecha" 
                        name="fecha" 
                        type="hidden" 
                        value="<?php echo e(date("Y-m-d")); ?>">

                    <input 
                        id="estado" 
                        name="estado" 
                        type="hidden" 
                        value="1">


                    <button type="submit" name="enviar" id="enviar" class="w-50 mx-auto my-3 fs-5 text-center text-white botonVioleta">Enviar</button>
                </form>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/contratarForm.blade.php ENDPATH**/ ?>