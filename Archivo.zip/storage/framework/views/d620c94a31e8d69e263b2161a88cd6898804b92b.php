<?php
/** @var \Illuminate\Database\Elocuent\Collection | \App\Models\Camiseta[] $camisetas */
?>



<?php $__env->startSection('title', 'Catalogo | Panel de administración'); ?>


<?php $__env->startSection('main'); ?>
<section class="container my-3">
    <h1>Administrar catálogo de camisetas</h1>
    <a href="<?php echo e(route('admin.catalogo.nuevaForm')); ?>" class="btn btn-dark fs-4 fw-bold my-3 text-decoration-none text-white">Agregar una camiseta</a>

    <table class="table table-hover table-bordered mb-2">
        <thead>
            <tr>
                <th>Id</th>
                <th>Título</th>
                <th>País</th>
                <th>Equipo</th>
                <!-- <th>Continente</th> -->
                <th>Precio</th>
                <th>Imagen</th> 
                <th>Acciones</th> 
            </tr>    
        </thead>
        <tbody>
            <?php $__currentLoopData = $camisetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camiseta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($camiseta->id); ?></td>
                    <td><?php echo e($camiseta->titulo); ?></td>
                    <td><?php echo e($camiseta->pais); ?></td> 
                    <td><?php echo e($camiseta->equipo); ?></td>
                    <td>$<?php echo e($camiseta->precio); ?></td>
                    <td><img src="" alt="" height="70" width="70"></td>
                    <td class="d-flex justify-content-evenly">
                        <a href="<?php echo e(route('admin.catalogo.detalle', ['id' => $camiseta->id])); ?>" class="btn btn-dark my-auto">Ver detalle</a>
                        <a href="<?php echo e(route('admin.catalogo.editarForm', ['id' => $camiseta->id])); ?>" class="btn btn-primary my-auto">Editar</a>
                        <a href="<?php echo e(route('admin.catalogo.eliminarConfirmar', ['id' => $camiseta->id])); ?>" class="btn btn-danger my-auto">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/adminCatalogo.blade.php ENDPATH**/ ?>