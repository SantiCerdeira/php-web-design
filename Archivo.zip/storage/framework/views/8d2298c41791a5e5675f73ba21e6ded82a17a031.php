<?php $__env->startSection('title', 'Bienvenido'); ?>

<?php $__env->startSection('main'); ?>
<h1>Hola bienvenidos chicos</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/welcome.blade.php ENDPATH**/ ?>