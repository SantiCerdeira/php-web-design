<?php
/** @var \Illuminate\Database\Elocuent\Collection | \App\Models\Autor[] $autores */
/** @var \Illuminate\Database\Elocuent\Collection | \App\Models\Usuario[] $usuarios */
?>



<?php $__env->startSection('title', 'Usuarios | Panel de administración'); ?>

<?php $__env->startSection('main'); ?>
<section class="container my-3">
    <h1>Listados</h1>

    <article>
        <h2>Autores</h2>
        <table class="table table-hover table-bordered mb-2">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Rol de usuario</th>
                </tr>    
            </thead>
            <tbody>
                <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($autor->nombre); ?></td>
                        <td><?php echo e($autor->apellido); ?></td>
                        <td>Autor</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </article>

    <article>
        <h2>Usuarios</h2>
        <table class="table table-hover table-bordered mb-2">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Rol de usuario</th>
                </tr>    
            </thead>
            <tbody>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($usuario->usuario_id); ?></td>
                        <td><?php echo e($usuario->nombre); ?></td>
                        <td><?php echo e($usuario->apellido); ?></td>
                        <td><?php echo e($usuario->email); ?></td>
                        <td>Administrador</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/adminUsuarios.blade.php ENDPATH**/ ?>