<?php
/**@var  \App\Models\Compra  $compra*/
?>



<?php $__env->startSection('title', 'Cancelar compra'); ?>

<?php $__env->startSection('main'); ?>

<section class="container seccionesLargoMinimo bg-white p-5 rounded">
    <h1 class="fs-1 mb-3">Cancelar compra <?php echo e($compra->compra_id); ?></h1>
    <article>
        <table class="table table-hover table-bordered mb-2">
            <thead>
                <tr>
                    <th>Id de la compra</th>
                    <th>Servicio contratado</th>
                    <th>Fecha</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <tr> 
                    <td><?php echo e($compra->compra_id); ?></td>
                    <td>
                        <?php if($compra->servicio_id == 1): ?>
                            Asesoría básica
                        <?php else: ?>
                            Asesoría en vivo
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($compra->fecha); ?></td>
                    <td>$<?php echo e($compra->total); ?></td> 
                </tr>
            </tbody>
        </table>
        <div class="mt-5">
            <h2 class="text-center fs-3">¿Desea cancelar esta compra? Esta acción no se puede deshacer</h2>
            <div class="d-flex justify-content-around w-50 mx-auto py-3">
                <a href="<?php echo e(route('compras', ['id' => Auth::user()->usuario_id])); ?>" class="btn btn-dark p-3 fs-5">Volver a mis compras</a>
                <form action="<?php echo e(route('cancelarCompra', ['id' => Auth::user()->usuario_id, 'compra_id' => $compra->compra_id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger p-3 fs-5">Cancelar compra</button>
                </form>
            </div>
        </div>
    </article>        
 </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/comprasCancelar.blade.php ENDPATH**/ ?>