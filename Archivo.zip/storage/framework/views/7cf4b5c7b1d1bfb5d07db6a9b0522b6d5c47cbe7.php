<?php
/**@var  \App\Models\Servicio[]  $servicios*/
?>



<?php $__env->startSection('title', 'Contratar WebExpert'); ?>

<?php $__env->startSection('main'); ?>
<section class="seccionesLargoMinimo">
    <h1 class="fs-1 text-center mt-3 p-3 text-white">Contrata los servicios de WebExpert</h1>
    <div class="d-flex justify-content-center flex-wrap my-3 container">
        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="planes col-11 col-lg-4 mx-3 my-2 d-flex flex-column">
                <h2><?php echo e($servicio->nombre); ?></h2>
                <p class="precio">$<?php echo e($servicio->precio); ?></p>
                <p class="mx-4"><?php echo e($servicio->descripcion); ?></p>
                <a href="<?php echo e(route('mp.confirmar', ['servicio_id' => $servicio->servicio_id])); ?>" class="btn btn-dark text-center w-75 mx-auto fs-5 p-3 m-2">¡Quiero este servicio!</a>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/contratar.blade.php ENDPATH**/ ?>