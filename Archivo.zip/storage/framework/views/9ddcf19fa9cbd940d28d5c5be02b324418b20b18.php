<?php
/** @var \Illuminate\Database\Elocuent\Collection | \App\Models\Usuario[] $usuarios */
?>



<?php $__env->startSection('title', 'Usuarios | Panel de administración'); ?>

<?php $__env->startSection('main'); ?>
<section class="container my-3">
    <h1>Listado de usuarios</h1>

    <article>
        <table class="table table-hover table-bordered my-4">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Email</th>
                    <th>Rol de usuario</th>
                    <th>Compras</th>
                </tr>    
            </thead>
            <tbody>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($usuario->usuario_id); ?></td>
                        <td><?php echo e($usuario->nombre); ?></td>
                        <td><?php echo e($usuario->apellido); ?></td>
                        <td><?php echo e($usuario->email); ?></td>
                        <td>
                            <?php if($usuario->rol == 1): ?>
                                Administrador
                            <?php elseif($usuario->rol == 2): ?>
                                Cliente
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($usuario->rol == 1): ?>
                                <i>No hay compras</i>
                            <?php elseif($usuario->rol == 2): ?>
                                <a href="<?php echo e(route('admin.usuarios.compras', ['id' => $usuario->usuario_id])); ?>" class="btn btn-dark px-3 w-100">Ver compras</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/admin/adminUsuarios.blade.php ENDPATH**/ ?>