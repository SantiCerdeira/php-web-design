<?php
/** @var \Illuminate\Database\Elocuent\Collection | \App\Models\Articulo[] $articulos */
?>



<?php $__env->startSection('title', 'Artículos | Panel de administración'); ?>

<?php $__env->startSection('main'); ?>
<section class="container my-3">
    <h1>Administrar artículos del blog</h1>
    <a href="<?php echo e(route('admin.articulos.nuevoForm')); ?>" class="btn btn-dark fs-4 fw-bold my-3 text-decoration-none text-white">Agregar un nuevo artículo</a>

    <article>
        <table class="table table-hover table-bordered mb-2">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Cuerpo</th>
                    <th>Portada</th>
                    <th>Descripción portada</th>
                    <th>Autor</th>
                    <th>Fecha de publicación</th> 
                    <th>Acciones</th> 
                </tr>    
            </thead>
            <tbody>
                <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($articulo->articulo_id); ?></td>
                        <td><?php echo e($articulo->titulo); ?></td>
                        <td><i>Entra a detalle para ver</i></td> 
                        <td><i>Entra a detalle para ver</i></td> 
                        <td>
                            <img src="<?php echo e(url('img/' . $articulo->portada)); ?>" alt="<?php echo e($articulo->portada); ?>" class="mw-100 my-2">
                        </td>
                        <td><?php echo e($articulo->portada_descripcion); ?></td>
                        <td><?php echo e($articulo->autor->nombre); ?></td>
                        <td><?php echo e($articulo->fecha_publicacion); ?></td>
                        <td class="d-flex justify-content-evenly flex-column">
                            <a href="<?php echo e(route('admin.articulos.detalle', ['id' => $articulo->articulo_id])); ?>" class="btn btn-dark my-2 mx-2">Ver detalle</a>
                            <a href="<?php echo e(route('admin.articulos.editarForm', ['id' => $articulo->articulo_id])); ?>" class="btn btn-primary my-2 mx-2">Editar</a>
                            <a href="<?php echo e(route('admin.articulos.eliminarConfirmar', ['id' => $articulo->articulo_id])); ?>" class="btn btn-danger my-2 mx-2">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </article>

    <?php if(count($articulos) == 0): ?>
        <h2 class="text-center my-5">Por el momento no hay artículos en el blog...</h2>
    <?php endif; ?>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/programacion/proyecto1/resources/views/adminArticulos.blade.php ENDPATH**/ ?>